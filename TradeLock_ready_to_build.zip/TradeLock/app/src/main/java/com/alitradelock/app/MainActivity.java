package com.alitradelock.app;

import android.app.*;import android.os.*;import android.provider.Settings;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView status,counter,untilView; int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(z);v.setPadding(dp(12),dp(8),dp(12),dp(8));return v;}
    Button b(String s){Button x=new Button(this);x.setText(s);x.setAllCaps(false);return x;}

    public void onCreate(Bundle x){super.onCreate(x);ui();refresh();}

    void ui(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(18));root.setBackgroundColor(Color.rgb(16,20,24));
        root.addView(t("🔒 TradeLock",28));
        root.addView(t("محافظ سخت‌گیر در برابر اورترید — MT5 و اپ‌های انتخابی",16));
        root.addView(t("⏰ قانون ثابت MT5: فقط 16:30 تا 18:00 به وقت ساعت گوشی",15));
        status=t("",19);counter=t("",16);untilView=t("",15);root.addView(status);root.addView(counter);root.addView(untilView);
        Button sl1=b("ثبت استاپ ۱"),sl2=b("ثبت استاپ ۲"),apps=b("📱 انتخاب اپ‌های قابل قفل"),lock=b("🔒 فعال‌کردن قفل"),acc=b("⚙ فعال‌سازی Accessibility"),reset=b("↩️ ریست شمارنده استاپ‌ها");
        root.addView(sl1);root.addView(sl2);root.addView(apps);root.addView(lock);root.addView(acc);root.addView(reset);
        root.addView(t("قانون پیشنهادی: بعد از استاپ دوم، بدون جنگ ذهنی قفل را فعال کن. هنگام قفل دکمه Unlock داخل TradeLock وجود ندارد و قفل بعد از بسته‌شدن برنامه یا ری‌استارت گوشی هم باقی می‌ماند.",14));
        setContentView(root);
        sl1.setOnClickListener(v->{if(!TradeLockStore.locked(this)){TradeLockStore.sl(this,1);refresh();}});
        sl2.setOnClickListener(v->{if(!TradeLockStore.locked(this)){TradeLockStore.sl(this,2);refresh();}});
        apps.setOnClickListener(v->appDialog());
        lock.setOnClickListener(v->lockDialog());
        acc.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        reset.setOnClickListener(v->{if(!TradeLockStore.locked(this)){TradeLockStore.resetSL(this);refresh();}});
    }

    void appDialog(){
        String[] names={"MetaTrader 5","MetaTrader 4","TradingView","Binance","CoinMarketCap","Chrome"};
        String[] ids={"net.metaquotes.metatrader5","net.metaquotes.metatrader4","com.tradingview.tradingviewapp","com.binance.dev","com.coinmarketcap.android","com.android.chrome"};
        Set<String>s=TradeLockStore.apps(this);boolean[] checked=new boolean[ids.length];for(int i=0;i<ids.length;i++)checked[i]=s.contains(ids[i]);
        new AlertDialog.Builder(this).setTitle("اپ‌هایی که هنگام Lock مسدود شوند").setMultiChoiceItems(names,checked,(d,w,on)->{if(on)s.add(ids[w]);else s.remove(ids[w]);TradeLockStore.setApps(this,s);}).setPositiveButton("ذخیره",null).show();
    }

    void lockDialog(){
        if(TradeLockStore.locked(this)){Toast.makeText(this,"قفل از قبل فعال است.",Toast.LENGTH_SHORT).show();return;}
        if(TradeLockStore.sl(this)<2){Toast.makeText(this,"اول دو استاپ را ثبت کن.",Toast.LENGTH_SHORT).show();return;}
        String[] c={"۲ ساعت","۴ ساعت","۸ ساعت","۱۲ ساعت","۱۶ ساعت","۱۸ ساعت","۲۰ ساعت","۲۴ ساعت","تا نیمه‌شب","مدت دلخواه…"};
        new AlertDialog.Builder(this).setTitle("مدت قفل قطعی").setMessage("بعد از تأیید، لغو قفل از داخل TradeLock ممکن نیست.").setItems(c,(d,w)->chooseDuration(w)).setNegativeButton("لغو",null).show();
    }

    void chooseDuration(int w){
        if(w==8){confirmLock(TradeLockStore.midnight());return;}
        if(w==9){ customHours(); return; }
        int[] hours={2,4,8,12,16,18,20,24}; confirmLock(System.currentTimeMillis()+hours[w]*3600000L);
    }

    void customHours(){
        final EditText e=new EditText(this);e.setInputType(2|8192);e.setHint("مثلاً 17.5");
        new AlertDialog.Builder(this).setTitle("مدت دلخواه (ساعت)").setMessage("مثلاً 17.5 یعنی ۱۷ ساعت و ۳۰ دقیقه.").setView(e).setNegativeButton("لغو",null).setPositiveButton("قفل کن",(d,w)->{
            try{double h=Double.parseDouble(e.getText().toString());if(h<=0||h>168)throw new Exception();confirmLock(System.currentTimeMillis()+(long)(h*3600000L));}
            catch(Exception ex){Toast.makeText(this,"عدد بین 0 و 168 ساعت وارد کن.",Toast.LENGTH_LONG).show();}
        }).show();
    }

    void confirmLock(long until){
        new AlertDialog.Builder(this).setTitle("🔒 قفل را قطعی می‌کنی؟").setMessage("بعد از تأیید، تا پایان زمان انتخاب‌شده داخل TradeLock گزینه‌ای برای لغو قفل وجود ندارد.").setNegativeButton("برگرد",null).setPositiveButton("بله، قفل کن",(d,w)->{TradeLockStore.lock(this,until);startActivity(new Intent(this,LockActivity.class));}).show();
    }

    void refresh(){
        boolean q=TradeLockStore.locked(this);status.setText(q?"🔒 قفل فعال":"🟢 آزاد");
        counter.setText("استاپ: "+TradeLockStore.sl(this)+" / 2   |   اپ‌های انتخاب‌شده: "+TradeLockStore.apps(this).size());
        untilView.setText(q?"تا: "+TradeLockStore.formatUntil(this):"قفل فعال نیست");
    }
    protected void onResume(){super.onResume();refresh();}
}
