package com.alitradelock.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class LockActivity extends Activity {
    TextView timer;
    TextView message;
    Handler h=new Handler(Looper.getMainLooper());
    Runnable r=()->update();

    void update(){
        boolean windowClosed=!TradeLockStore.mt5TradingWindowOpen();
        boolean locked=TradeLockStore.locked(this);
        if(!locked && !windowClosed){ finish(); return; }
        if(windowClosed){
            timer.setVisibility(View.GONE);
            message.setText("⏰ متاتریدر 5 فقط بین 16:30 تا 18:00\nبه وقت ساعت گوشی قابل استفاده است.\n\nخارج از این بازه، MT5 قفل است و این زمان از داخل TradeLock قابل تغییر نیست.");
        }else{
            timer.setVisibility(View.VISIBLE);
            message.setText("دو استاپ ثبت شده است.\nمعامله امروز تمام است.");
            long x=TradeLockStore.until(this)-System.currentTimeMillis();
            long sec=Math.max(0,x/1000);
            timer.setText(String.format(Locale.getDefault(),"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60));
        }
        h.postDelayed(r,1000);
    }

    public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER); l.setPadding(30,30,30,30);
        l.setBackgroundColor(Color.rgb(10,12,15));
        TextView a=new TextView(this); a.setText("🔒 TRADING LOCKED"); a.setTextColor(Color.rgb(24,199,192)); a.setTextSize(30); a.setGravity(17);
        message=new TextView(this); message.setTextColor(Color.WHITE); message.setTextSize(18); message.setGravity(17);
        timer=new TextView(this); timer.setTextColor(Color.WHITE); timer.setTextSize(42); timer.setGravity(17);
        l.addView(a); l.addView(message); l.addView(timer); setContentView(l);
    }
    protected void onResume(){super.onResume(); h.removeCallbacks(r); update();}
    protected void onPause(){super.onPause(); h.removeCallbacks(r);}
    public void onBackPressed(){}
}
