package com.alitradelock.app;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.view.accessibility.AccessibilityEvent;

public class TradeLockAccessibilityService extends AccessibilityService {
    private static final String MT5 = "net.metaquotes.metatrader5";

    public void onAccessibilityEvent(AccessibilityEvent e){
        CharSequence p=e.getPackageName();
        if(p==null)return;
        String pkg=p.toString();
        boolean mt5Blocked = MT5.equals(pkg) && !TradeLockStore.mt5TradingWindowOpen();
        boolean selectedBlocked = TradeLockStore.locked(this) && TradeLockStore.apps(this).contains(pkg);
        if(mt5Blocked || selectedBlocked){
            Intent i=new Intent(this,LockActivity.class);
            i.putExtra("reason", mt5Blocked ? "window" : "lock");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        }
    }
    public void onInterrupt(){}
}
