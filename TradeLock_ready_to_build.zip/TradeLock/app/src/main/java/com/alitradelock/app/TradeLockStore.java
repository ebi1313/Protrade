package com.alitradelock.app;

import android.content.*; import java.util.*; import java.text.*;

public final class TradeLockStore {
    private static final String P="tradelock", UNTIL="until", SL="sl", APPS="apps";
    static android.content.SharedPreferences p(Context c){return c.getSharedPreferences(P,Context.MODE_PRIVATE);}
    static int sl(Context c){return p(c).getInt(SL,0);}
    static void sl(Context c,int n){p(c).edit().putInt(SL,Math.min(2,Math.max(0,n))).apply();}
    static void resetSL(Context c){p(c).edit().putInt(SL,0).apply();}
    static long until(Context c){return p(c).getLong(UNTIL,0);}
    static boolean locked(Context c){return until(c)>System.currentTimeMillis();}
    static void clear(Context c){p(c).edit().remove(UNTIL).apply();}
    // Fixed MT5 trading window: device local time, 16:30 (inclusive) to 18:00 (exclusive).
    static boolean mt5TradingWindowOpen(){Calendar x=Calendar.getInstance();int m=x.get(Calendar.HOUR_OF_DAY)*60+x.get(Calendar.MINUTE);return m>=16*60+30 && m<18*60;}
    static String mt5WindowText(){return "MT5 فقط بین 16:30 تا 18:00 به وقت ساعت گوشی قابل استفاده است.";}
    static void lock(Context c,long t){p(c).edit().putLong(UNTIL,t).apply();}
    static java.util.Set<String> apps(Context c){return new java.util.HashSet<>(p(c).getStringSet(APPS,new java.util.HashSet<>()));}
    static void setApps(Context c,Set<String> s){p(c).edit().putStringSet(APPS,new HashSet<>(s)).apply();}
    static long midnight(){Calendar x=Calendar.getInstance();x.add(Calendar.DAY_OF_YEAR,1);x.set(Calendar.HOUR_OF_DAY,0);x.set(Calendar.MINUTE,0);x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);return x.getTimeInMillis();}
    static String formatUntil(Context c){return new SimpleDateFormat("yyyy/MM/dd  HH:mm",Locale.getDefault()).format(new Date(until(c)));}
}
